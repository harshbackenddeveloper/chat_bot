const socket = io();





// const message = document.getElementById('messages');
// const sendMessage = document.getElementById('sendMessage');
// const messages = document.getElementById('messages');

/*
const inputMessage = document.getElementById('inputMessage');
socket.on('chat message', function(msg) {
    document.getElementById('input').value = msg;
});
*/


// socket.on('connect', (message) => {
//     const messageElement = document.createElement('p');
//     messageElement.innerText = message;
//     messages.appendChild(messageElement);
// });




// sendMessage.addEventListener('click',()=>{
//     const message = inputMessage.value;
//     socket.emit('message', message);
//     inputMessage.value = '';
// });




// socket.on('botMessage', (message) => {
//     const messageElement = document.createElement('p');
//     messageElement.innerText = message;
//     messages.appendChild(messageElement);
// });